# RianConverter 2.0

Double-click **RianConverter.exe**. This is the only application file you need to download or copy. Processing is offline, with no account, API key, installer or conversion-engine download.

Requires Windows 10 or newer and .NET Framework 4.8. The same executable supports 32-bit and 64-bit Windows, including Windows 11.

## Supported formats

39 format types across 43 extensions, including aliases:

| Category | Formats |
| --- | --- |
| Documents | DOCX, PPTX, PDF, TXT, RTF; HTML output |
| Images | PNG, JPEG/JPG, BMP, GIF, TIFF/TIF, ICO, WebP |
| Audio | MP3, WAV, FLAC, AAC, M4A, OGG, Opus, WMA, AIFF/AIF |
| Video | MP4/M4V, MKV, AVI, MOV, WebM, WMV, FLV, 3GP |
| Subtitles | SRT, VTT, ASS, SSA |
| Table data | CSV, TSV, JSON, XML |
| Archives | Create and extract ZIP files |

Add files or drag them into the list. **Convert To** shows outputs supported by at least one input. Incompatible files are marked Unsupported and skipped. Choose an output folder, then click **Convert**. Double-click a row for its full error or output path.

## Conversion behavior

- Portable document conversion uses text and embedded pictures with simplified layout. Word/text to PowerPoint creates text slides. PDF to PowerPoint creates one image per page.
- PDF to Word contains extracted text and page snapshots. It does not reconstruct a fully editable original layout. Scan-only PDFs retain page pictures; OCR is not included.
- TXT, RTF and HTML output contain text only. HTML input is not supported.
- Images use the first frame/page. JPEG and BMP flatten transparency onto white. PDF to PNG/JPEG saves every page in a new folder.
- Video keeps the first video track and first audio track where present. Video-to-audio extracts the first audio track. Extra tracks and most metadata are omitted. Lossy conversions can reduce quality.
- Tables accept CSV/TSV, arrays of flat JSON row objects, and RianConverter table XML. Nested JSON/XML is rejected. Values become text. Use UTF-8 text; common Unicode byte-order marks are detected.
- ZIP creation packages each original into its own archive. Extraction creates a new folder and rejects unsafe paths, links and oversized entries. Extracted files are not run.

Source files are preserved. Existing outputs are never overwritten; duplicates receive numbered suffixes. A failed file does not stop the queue.

## Included tools and settings

Media and PDF engines are embedded in the executable and extracted automatically into `%LOCALAPPDATA%\RianConverter\Runtime` on first use. This is local extraction, not a download. Preferences are stored in `%LOCALAPPDATA%\RianConverter\settings.xml`.

Portable mode is the default and needs no Office installation. An optional Settings checkbox can use already installed Word/PowerPoint or configured LibreOffice for higher-fidelity document PDF conversion. These optional programs are not bundled.

**Settings → Included Components** displays the component licenses and can save the full notices. Source code and test details are in the separate Source folder.

MPEG/MPG output, full spreadsheet conversion, OCR, CAD/3D, DRM-protected media, cloud conversion and same-format reprocessing are not included. Supported formats do not imply every possible conversion between them.